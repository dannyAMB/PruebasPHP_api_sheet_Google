<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>My app PHP Api</h2>

  <?php



require '../vendor/autoload.php'; // Carga automática de Composer

use Google\Client;
use Google\Service\Sheets;

// Ruta al archivo de credenciales JSON descargado desde Google Cloud
$credentialsPath = 'credenciales_cuenta_de_servicios.json';

// ID de la hoja de cálculo (lo encuentras en la URL de tu Google Sheet)
$spreadsheetId = '1_ssXPyHY1pVg_xZuyqBDdeM3D06J3bGvYr6Tb_4Q9oA';

// Rango donde quieres insertar los datos (por ejemplo, "Hoja1!A1")
$range = 'datos!A1';

// Datos a enviar (una fila con tres columnas)
$data = [
    ['Nombre', 'Email', 'Mensaje'], // Cabeceras
    ['Juan', 'juan@ejemplo.com', 'Hola desde PHP'], // Primera fila
];
$http = new GuzzleHttp\Client(['verify' => 'cacert.pem']);

// Crea el cliente de Google
$client = new  Google_Client();
$client->setHttpClient($http);
$client->setAuthConfig($credentialsPath);
$client->addScope(Sheets::SPREADSHEETS);

// Autenticar al usuario
$client->setAccessType('offline');
$client->setApprovalPrompt('force');

// Crea el servicio de Google Sheets
$service = new Sheets($client);

// Prepara los datos para enviar
$body = new Sheets\ValueRange([
    'values' => $data
]);

// Configuración de inserción
$params = [
    'valueInputOption' => 'RAW' // O 'USER_ENTERED' para formatear como lo haría un usuario
];

try {
    // Inserta los datos en la hoja
    $result = $service->spreadsheets_values->append(
        $spreadsheetId,
        $range,
        $body,
        $params
    );

    echo "{$result->getTableRange() } celdas actualizadas.";
} catch (Exception $e) {
    echo 'Error al enviar los datos: ' . $e->getMessage();
}
?>
 


</body>
</html>