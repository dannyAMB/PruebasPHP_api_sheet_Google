<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>My app PHP Api</h2>

  <?php



require '../vendor/autoload.php'; // Carga automática de Composer

use Google\Client;
use Google\Service\Sheets;


// Ruta al archivo de credenciales JSON descargado desde Google Cloud
$credentialsPath = 'credenciales.json';

// ID de la hoja de cálculo (lo encuentras en la URL de tu Google Sheet)
$spreadsheetId = '1_ssXPyHY1pVg_xZuyqBDdeM3D06J3bGvYr6Tb_4Q9oA';

// Rango donde quieres insertar los datos (por ejemplo, "Hoja1!A1")
$range = 'datos!A1';

// Datos a enviar (una fila con tres columnas)
$data = [
    ['Nombre', 'Email', 'Mensaje'], // Cabeceras
    ['Juan', 'juan@ejemplo.com', 'Hola desde PHP'], // Primera fila
];

//instalar cacert.pem
$http = new GuzzleHttp\Client(['verify' => 'C:/PHP/extras/ssl/cacert.pem']);

// Crea el cliente de Google
$client = new  Google_Client();
$client->setHttpClient($http);
$client->setAuthConfig($credentialsPath);
$client->addScope(Google\Service\Sheets::SPREADSHEETS);
$client->setRedirectUri('http://localhost'); // URI de redirección configurado en Google Cloud Console

// Verifica si ya hay un token guardado
$tokenPath = 'token.json';
if (file_exists($tokenPath)) {
    $accessToken = json_decode(file_get_contents($tokenPath), true);
    $client->setAccessToken($accessToken);
}

// Si no hay token o ha expirado, solicita autenticación
if ($client->isAccessTokenExpired()) {
    if ($client->getRefreshToken()) {
        $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
    } else {
        $authUrl = $client->createAuthUrl();

        
        printf("Abre este enlace en tu navegador:\n%s\n", $authUrl);
        ?>

        <a href="<?php echo $authUrl ?>" target="_blank"> sddsds<?php echo $authUrl ?></a>

        <?php
        print 'Introduce el código de autenticación: ';
       $authCode = trim(fgets(STDIN));

        $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
        $client->setAccessToken($accessToken);

        // Guarda el token para futuras solicitudes
        if (!file_exists(dirname($tokenPath))) {
            mkdir(dirname($tokenPath), 0700, true);
        }
        file_put_contents($tokenPath, json_encode($accessToken));
    }
}


// Crea el servicio de Google Sheets
$service = new Sheets($client);

// Prepara los datos para enviar
$body = new Sheets\ValueRange([
    'values' => $data
]);

// Configuración de inserción
$params = [
    'valueInputOption' => 'RAW' // O 'USER_ENTERED' para formatear como lo haría un usuario
];

try {
    // Inserta los datos en la hoja
    $result = $service->spreadsheets_values->append(
        $spreadsheetId,
        $range,
        $body,
        $params
    );

    echo "{$result->getTableRange() } celdas actualizadas.";
} catch (Exception $e) {
    echo 'Error al enviar los datos: ' . $e->getMessage();
}
?>


</body>
</html>