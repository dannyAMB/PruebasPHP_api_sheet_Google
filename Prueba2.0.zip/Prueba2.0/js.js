const SPREADSHEET_ID = '1_ssXPyHY1pVg_xZuyqBDdeM3D06J3bGvYr6Tb_4Q9oA';
const API_KEY = 'AIzaSyBe3biCULdP3xncGLuj7nnG4XyOs3NbPUk';

const url = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/datos!A1:A10?key=${API_KEY}`;

fetch(url)
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
    .catch(error => {
        console.error('Error en la solicitud GET:', error);
    });