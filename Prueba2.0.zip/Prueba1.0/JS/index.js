const scriptURL = 'https://script.google.com/a/macros/iudigital.edu.co/s/AKfycbxMiabg_2UvYXXPUcHth2XflZfy9u23XjulanaOrqkVnBAenAoNq0Gqk3oC0NVbZfPwEA/exec'

const form = document.forms['contact-form']

form.addEventListener('submit', e => {
  
  e.preventDefault()
  
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  .then(response => alert("Thank you! Form is submitted" ))
  .then(() => { window.location.reload(); })
  .catch(error => console.error('Error!', error.message))
})